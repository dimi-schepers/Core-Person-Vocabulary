Project Description
=====================================================
A Core Vocabulary is a simplified, reusable, and extensible data model that captures the fundamental characteristics of an entity in a context-neutral way. Well known examples of existing Core Vocabularies include the Dublin Core Metadata Set. E-Government Core Vocabularies are the starting point for developing interoperable e-Government systems as it allows mappings with existing data models. This guarantees Public Administrations to attain cross-border and cross-sector interoperability. This packages contains XML Schemas for the following Core Vocabularies:
 
- The Core Business Vocabulary is a simplified, reusable and extensible data model that captures the fundamental characteristics of a legal entity, e.g. the legal name, the activity, address, ...

- The Core Person Vocabulary is a simplified, reusable and extensible data model that captures the fundamental characteristics of a person, e.g. the name, the gender, the date of birth, the location, ...

- The Core Location Vocabulary is a simplified, reusable and extensible data model that captures the fundamental characteristics of a location, represented as an address, a geographic name, or a geometry.

The XML Schemas are based on UBL.

Release Information
=====================================================
CoreVocabularies-v1.00 XML Schemas, implementing the Core Vocabularies specification for Core Person, Core Business and Core Location.

Release date: 09/05/2012


Package Structure
=====================================================
This release of the Core Vocabularies XML Schemas is published as a zip archive named CoreVocabularies_XML_Schemas-v1.00. Unzipping this archive creates a directory named CoreVocabularies_XML_Schemas-v1.00 containing this readme-file, 3 PNG-files representing the Core Person, Core Business and Core Location XML Schemas in their entirety in visual format and a number of subdirectories. The files in the subdirectories contain the various normative and informational pieces of this release. A description of each subdirectory is given below.

doc
Contains documention on the Core Vocabularies XML Schemas. Inside the html subdirectory, navigate to the CorePerson, CoreBusiness or CoreLocation subdirectory and open the HTML-file to open the documentation in the browswer. The UBL ndr subdirectory contains a checklist for all UBL Naming and Design Rules (version 2.0).

mod
Contains the source ODS and XLS file that can be used to generate the Core Vocabularies XML Schemas.

xsd
The common subdirectory contains schema's for the UBL data types and components. The Core Vocabularies XML Schema files are contained within the corevoc subdirectory.


Support
=====================================================
The Core Vocabularies are projects of the European Commission in the context of Action 1.1 of the ISA Programme. Inquiries regarding Core Vocabularies and these XML Schemas may be posted to the Core Vocabularies Community on Joinup, the European Commission collaborative platform, located at 
http://joinup.ec.europa.eu/community/core_vocabularies/home


Known Issues
=====================================================
There are no known issues in this release.



